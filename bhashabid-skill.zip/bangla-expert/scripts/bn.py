"""Bhashabid engine runner for sandboxes without the MCP server.
Usage: python scripts/bn.py <command> [args]   (same commands as the `bhashabid` CLI)
Examples:
  python scripts/bn.py date 2025-12-16 --bongabdo
  python scripts/bn.py number 1234567.50 --currency
  python scripts/bn.py prosody "পদ্মার ঢেউ ..." --verify-payar
  python scripts/bn.py lint "আপনার বাংলা লেখা"
  python scripts/bn.py repair "আপনার বাংলা লেখা"
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bhashabid.cli import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
