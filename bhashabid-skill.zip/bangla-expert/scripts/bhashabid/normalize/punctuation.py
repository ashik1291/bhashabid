# Bengali Punctuation Normalization
import re

DARI = "\u0964"  # । (Bengali Dari)
DOUBLE_DARI = "\u0965" # ॥ (Bengali Double Dari)

# Regex to safely protect URLs, web domains, and email addresses from Dari conversion
URL_OR_EMAIL_PATTERN = re.compile(
    r"(?:https?://[^\s।]+|ftp://[^\s।]+|www\.[^\s।]+|[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+)"
)

# Regexes to protect abbreviations, name initials, academic degrees, citations, and list markers
ABBR_AND_INITIALS_PATS = [
    # Multi-dot IP addresses and semantic version strings (ASCII and Bengali digits)
    r"(?<=\b)(?:\d{1,3}\.){3}\d{1,3}(?=\b)",
    r"(?<![\u0980-\u09FF])(?:[\u09E6-\u09EF]{1,3}\.){3}[\u09E6-\u09EF]{1,3}(?![\u0980-\u09FF])",
    r"(?<![\u0980-\u09FF])(?:ভ|v)?[\u09E6-\u09EF\d]+\.[\u09E6-\u09EF\d]+(?:\.[\u09E6-\u09EF\d]+)+(?![\u0980-\u09FF])",

    # Numbered and lettered list markers (e.g. ১. , ২. , ক. , খ. , 1. , a. )
    r"(?:^|(?<=[\s\n(]))(?:[\u09E6-\u09EF]+|\d+|[ক-হ])\.(?=\s)",

    # Bengali honorifics and titles (e.g. ড. , ডা. , মো. , মোঃ , প্রফে. , লে. , মে. , মি. , মিস. , অ্যাড. , ব্যারিস্টার. , ইঞ্জি. , প্রফেসর.)
    r"(?<![\u0980-\u09FF])(?:ড|ডা|মো|মোঃ|প্রফে|লে|মে|মি|মিস|অ্যাড|ব্যারিস্টার|ইঞ্জি|প্রফেসর)\.(?=\s|[\u0980-\u09FF]|$)",

    # Scholarly, legal, business, and bibliographic abbreviations (e.g. পৃ. , নং. , খ্রি. , খ্রি.পূ. , বি.দ্র. , তাং. , ইং. , ভলু. , খণ্ড. , অনু. , ইত্যা. , লি. , কোং.)
    r"(?<![\u0980-\u09FF])(?:পৃ|নং|খ্রি|খ্রি\.পূ|বি\.দ্র|তাং|ইং|ভলু|খণ্ড|অনু|ইত্যা|লি|কোং)\.(?=\s|[\u0980-\u09FF\d\u09E6-\u09EF]|$)",

    # Multi-letter academic degrees & credentials (e.g. এম.বি.বি.এস. , পিএইচ.ডি. , বি.এ. , এম.এ. , বি.এসসি. , এম.এসসি. , বি.বি.এ. , এম.বি.এ. , বি.কম. , এম.কম. , এলএল.বি. , এলএল.এম. , বি.এড. , এম.এড. , সি.এ.)
    r"(?<![\u0980-\u09FF])(?:এম\.বি\.বি\.এস|পিএইচ\.ডি|বি\.এ|এম\.এ|বি\.এসসি|এম\.এসসি|বি\.বি\.এ|এম\.বি\.এ|বি\.কম|এম\.কম|এলএল\.বি|এলএল\.এম|বি\.এড|এম\.এড|সি\.এ)\.",

    # Name initials (Bengali single letter or transliterated letter followed by dot, e.g. এস. এ. , টি. এস. , এ. কে. , জে. আর. , ডব্লিউ. বি.)
    r"(?<![\u0980-\u09FF])(?:[অ-হড়ঢ়য়ৎ]|এস|টি|এ|কে|জে|আর|ডব্লিউ|বি|সি|ডি|ই|এফ|জি|এইচ|আই|এম|এন|ও|পি|কিউ|ইউ|ভি|এক্স|ওয়াই|জেড)\.(?=\s*(?:[অ-হড়ঢ়য়ৎ]|এস|টি|এ|কে|জে|আর|ডব্লিউ|বি|সি|ডি|ই|এফ|জি|এইচ|আই|এম|এন|ও|পি|কিউ|ইউ|ভি|এক্স|ওয়াই|জেড)\.|\s+[\u0980-\u09FF])"
]

PROTECTED_ABBR_PATTERN = re.compile("|".join(f"(?:{p})" for p in ABBR_AND_INITIALS_PATS))

def normalize_punctuation(text: str, convert_period_to_dari: bool = True) -> str:
    """
    Normalizes punctuation in Bengali text:
    1. Converts ASCII sentence-ending period (.) and ASCII pipe (|) to Bengali Dari (।) while strictly preserving:
       - Decimals (e.g. 3.14 or ৩.১৪)
       - Web URLs (e.g. https://www.tbsnews.net)
       - Email addresses (e.g. info@bangladesh.gov.bd)
       - Alphanumeric domain names and abbreviations (e.g. e.g., i.e., test.com)
       - Bengali abbreviations and initials (ড., ডা., মো., এস. এ., টি. এস., পৃ., নং., ১., ক.)
       - Academic credentials and degrees (এম.বি.বি.এস., পিএইচ.ডি., বি.এ., এম.এ.)
       - Markdown table rows (| col1 | col2 |) and non-Bengali shell/bitwise pipes
    2. Collapses repeated consecutive Dari characters (।। -> ।).
    3. Enforces standard typographic spacing:
       - Removes redundant whitespace before punctuation (ভাত খাই । -> ভাত খাই।)
       - Enforces single whitespace after sentence terminators (।, ॥, !, ?) when followed by words
    4. Standardizes quotation marks to typographical curved quotes.
    """
    if not text:
        return ""

    # Protect URLs and email addresses using temporary token masking
    masked_items = []
    def _mask_url_or_email(match):
        raw = match.group(0)
        trailing_period = ""
        # If URL ends with a sentence-terminating dot (e.g. 'visit site.com.'), don't swallow the dot
        if raw.endswith("."):
            raw = raw[:-1]
            trailing_period = "."
        idx = len(masked_items)
        masked_items.append(raw)
        return f"__BHASHABID_URL_MASK_{idx}__{trailing_period}"

    text = URL_OR_EMAIL_PATTERN.sub(_mask_url_or_email, text)

    # Protect abbreviations, name initials, academic degrees, citations, and list markers
    masked_abbrs = []
    def _mask_abbr(match):
        idx = len(masked_abbrs)
        masked_abbrs.append(match.group(0))
        return f"__BHASHABID_ABBR_MASK_{idx}__"

    text = PROTECTED_ABBR_PATTERN.sub(_mask_abbr, text)

    # 1. Convert ASCII pipe (|) used as Dari in Bengali text (protecting markdown tables and shell/code pipes)
    if re.search(r"[\u0980-\u09FF]", text):
        lines = text.split("\n")
        norm_lines = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("|") and stripped.endswith("|") and stripped.count("|") >= 2:
                norm_lines.append(line)
            else:
                if re.search(r"[\u0980-\u09FF]", line):
                    line = re.sub(r"(?<=[\u0980-\u09FF])\s*\|+(?=[\s\u0980-\u09FF\n]|$)", DARI, line)
                    line = re.sub(r"(?<=[\u0980-\u09FF\s])\|+(?=[\s\u0980-\u09FF\n]|$)", DARI, line)
                norm_lines.append(line)
        text = "\n".join(norm_lines)

    # 2. Convert ASCII period (.) to Bengali Dari (।) where appropriate (protecting ellipsis and decimals)
    text = re.sub(r"\.{2,}", "…", text)
    if convert_period_to_dari and re.search(r"[\u0980-\u09FF]", text):
        # 1. Do not convert if followed by ASCII/Bengali digit (decimals like 3.14, ৩.১৪)
        # 2. Do not convert if between ASCII alphanumeric characters (like site.com, node.js, e.g.)
        # 3. Only convert when preceded by Bengali word or at true sentence terminator
        def _replace_period(m):
            span_start = m.start()
            span_end = m.end()
            # Lookahead check for decimal
            after_char = text[span_end:span_end+1]
            if after_char and (after_char.isdigit() or "\u09E6" <= after_char <= "\u09EF"):
                return "."
            # Lookbehind and lookahead for ASCII domain/abbr (e.g. name.ext)
            before_char = text[span_start-1:span_start] if span_start > 0 else ""
            if before_char and after_char and before_char.isalnum() and after_char.isalpha():
                return "."
            return DARI

        text = re.sub(r"\.", _replace_period, text)

    # 3. Collapse multiple consecutive Daris (।। -> ।)
    text = re.sub(r"[\u0964]{2,}", DARI, text)

    # Restore protected abbreviations and initials
    for idx, original in enumerate(masked_abbrs):
        text = text.replace(f"__BHASHABID_ABBR_MASK_{idx}__", original)

    # Restore protected URLs and email addresses
    for idx, original in enumerate(masked_items):
        text = text.replace(f"__BHASHABID_URL_MASK_{idx}__", original)

    # Clean space before sentence ending marks
    text = re.sub(r"\s+([\u0964\u0965!?,;:])", r"\1", text)

    # Enforce standard space after sentence terminators (।, ॥, !, ?) when directly followed by word characters
    terminators = r"[\u0964\u0965!?]"
    closer_chars = r"[\"'”’\)\}\]]"
    text = re.sub(f"({terminators})(?!\\s|{terminators}|{closer_chars}|$)", r"\1 ", text)
    text = re.sub(f"({terminators}{closer_chars}+)(?!\\s|{terminators}|{closer_chars}|$)", r"\1 ", text)

    # Standardize ASCII quotes to curved Bengali quotes
    # Opening double quote (preceded by start/space/dash/punctuation, followed by letter)
    text = re.sub(r'(^|[\s—,;:])"([\u0980-\u09FFA-Za-z\'])', r'\1“\2', text)
    # Closing double quote (preceded by letter/punctuation, followed by end/space/dash/punctuation)
    text = re.sub(r'([\u0980-\u09FFA-Za-z\u0964!?,.;\'])\"($|[\s—\u0964!?,.;])', r'\1”\2', text)

    return text
